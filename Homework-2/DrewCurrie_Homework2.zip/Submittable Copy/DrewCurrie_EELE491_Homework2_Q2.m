%Spring 2026 EELE-491
%Drew Currie Homework-2
%Problem 2

%% Part 2 

%Generate mesh data

DecisionBoundryPlotter_2D(Question2TrilayeredNeuralNetwork, 'TriLayeredNeuralNetwork', meas)
DecisionBoundryPlotter_2D(Question2KNN, 'Medium KNN', meas)
DecisionBoundryPlotter_2D(Question2WeightedKNN, 'Weighted KNN', meas)
DecisionBoundryPlotter_2D(Question2LinearSVM, 'Linear SVM', meas)
DecisionBoundryPlotter_2D(Question2QuadraticSVM, 'Quadratic SVM', meas)
DecisionBoundryPlotter_2D(Question2MediumGaussianSVM, 'Medium Gaussian SVM', meas)
DecisionBoundryPlotter_2D(Question2FineTree, 'Fine Tree', meas)
DecisionBoundryPlotter_2D(Question2CoarseTree, 'Coarse Tree', meas)
